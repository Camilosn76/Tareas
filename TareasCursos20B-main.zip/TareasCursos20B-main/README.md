# TareasCursos20B
Este repostorio debe clonarse para reportar las tareas y asignaciones
Dispone de tres directorios: 
+ DocPDF (para albergar los documentos)
+ Codigos (para albergar los códigos creados a partir de los ejercicios)
+ Datos (para albergar los datos y/o resultados)
