Este directorio albergará los códigos desarrollados durante el curso como parte de las tareas y asignaciones
